// ignore_for_file: prefer_single_quotes
class Assets {
  Assets._();
  
  /// Assets for imagesAsd01
  /// assets/images/asd01.png
  static const String imagesAsd01 = "assets/images/asd01.png";

  /// Assets for imagesAsd02
  /// assets/images/asd02.jpg
  static const String imagesAsd02 = "assets/images/asd02.jpg";

  /// Assets for imagesMyProfile
  /// assets/images/myProfile.png
  static const String imagesMyProfile = "assets/images/myProfile.png";

}

