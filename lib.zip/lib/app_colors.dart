import 'package:flutter/material.dart';

class AppColors {
  static Color? primaryBackgroundColor = Colors.grey[200];
  static Color backgroundColor = const Color(0xff486581);
  static Color backgroundColorAppBar = const Color(0xff829AB1);
  static Color containerColor = const Color(0xffF0F4F8);
  static Color container1Color = const Color(0xffBCCCDC);
  static Color buttomColor = const Color(0xff243853);

}
