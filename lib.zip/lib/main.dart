import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:mutazan_plus/view/Login.dart';

import 'controler/Router.dart';
import 'controler/language_controller.dart';
import 'helpers/permissions_helper.dart';
import 'languages/translations.dart';
import 'model/company_model.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await PermissionsHelper.requestPermissions();
  await initHive();

  final languageController = Get.put(LanguageController());
  await languageController.loadSavedLanguage();

  runApp(const MyApp());
}

Future<void> initHive() async {
  await Hive.initFlutter();
  Hive.registerAdapter(CompanyAdapter());
  await Hive.openBox('settings');
  await Hive.openBox<Company>('companyBox');
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: "Khandevane"),
      locale: Get.find<LanguageController>().isArabic.value
          ? const Locale('ar', 'AE')
          : const Locale('en', 'US'),
      fallbackLocale: const Locale('en', 'US'),
      translations: AppTranslations(),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('ar', 'AE')],
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
      initialRoute: LoginScreenWithWelcome.routeName,
      getPages: AppRoutes.routes,
    );
  }
}
